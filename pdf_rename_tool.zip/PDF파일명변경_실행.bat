@echo off
chcp 65001 >nul
title PDF 파일명 자동 변경

cd /d %~dp0
python pdf_rename.py
