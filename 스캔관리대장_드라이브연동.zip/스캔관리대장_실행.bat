@echo off
chcp 65001 >nul
title 스캔관리대장 (구글 드라이브 연동)
cd /d %~dp0

echo =============================================
echo   스캔관리대장 구글 드라이브 연동 버전
echo =============================================
echo.
echo HTML 생성 중...
python generate_html.py once

echo.
echo 브라우저에서 열겠습니다...
start "" "%USERPROFILE%\Desktop\스캔\스캔관리대장.html"

echo.
echo 폴더 감시 중... (새 파일 추가 시 자동 업데이트)
echo 종료하려면 이 창을 닫으세요.
python generate_html.py
