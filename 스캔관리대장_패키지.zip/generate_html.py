"""
스캔관리대장 HTML 생성기
- 검색 기능
- 업무문서 분류 (날짜·종류·회사 컬럼)
- 파일 추가 감지 → 자동 갱신
"""
import os, re
from datetime import datetime
from pathlib import Path

SCAN_FOLDER = r"C:\Users\User\Desktop\스캔"
OUTPUT_HTML = os.path.join(SCAN_FOLDER, "스캔관리대장.html")

# ── 소송 파일 정의
LAWSUIT_FILES = {
    "(26.05.04)결정_인천지법(25라5671)_에스티엔 유치권.pdf": ("인천지방법원","에스티엔 유치권 결정","25라5671","결정문","긴급"),
    "260406_70거4454.pdf":("법원","70거4454 사건","70거4454","법원서류","주의"),
    "김윤석 소송.pdf":("김윤석","김윤석 소송","","소송관련","주의"),
    "답변서_2026가단104265_(어뮤즈).pdf":("어뮤즈","2026가단104265 답변서","2026가단104265","답변서","주의"),
    "부동산명령.pdf":("법원","부동산 명령","","법원명령","긴급"),
    "이강영 특가중.pdf":("이강영","특정범죄가중처벌 사건","","형사사건","긴급"),
    "이미정 개인회생 이체내역.pdf":("이미정","개인회생 이체내역","","회생관련","주의"),
    "이미정 개인회생 채권자목록.pdf":("이미정","개인회생 채권자목록","","회생관련","주의"),
    "이미정 개인회생 판결문.pdf":("이미정","개인회생 판결문","","판결문","주의"),
    "중부모범 답변서.pdf":("중부모범","중부모범 답변서","","답변서","주의"),
    "중부모범답변.pdf":("중부모범","중부모범 답변","","답변서","주의"),
    "에스티엔미디어 송출료소송.pdf":("에스티엔미디어","송출료 소송","","소송관련","주의"),
    "에스티엔미디어 중부모범.pdf":("에스티엔미디어/중부모범","중부모범 관련 서류","","소송관련","주의"),
    "차주화 진술서 (2).pdf":("차주화","차주화 진술서","","진술서","일반"),
    "사실확인서.pdf":("","사실확인서","","확인서류","일반"),
}

def get_date(fname):
    m = re.search(r'SCAN_(\d{4})(\d{2})(\d{2})_', fname)
    if m: return f"{m.group(1)}-{m.group(2)}-{m.group(3)}"
    m = re.search(r'\((\d{2})\.(\d{2})\.(\d{2})\)', fname)
    if m: return f"20{m.group(1)}-{m.group(2)}-{m.group(3)}"
    m = re.search(r'^(\d{2})(\d{2})(\d{2})_', fname)
    if m: return f"20{m.group(1)}-{m.group(2)}-{m.group(3)}"
    m = re.search(r'(202\d)[.\-](\d{1,2})[.\-](\d{1,2})', fname)
    if m: return f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    return "2026-05-17"

def get_company(fname):
    f = fname.replace(".pdf","")
    for co in ["에스티엔미디어","에스티엔뉴스","에스티엔방송","에스티엔","플래닛네이처미디어",
               "플레닛네이처","플래닛부동산","플레닛","코퍼레이션","다이즈하이미디어",
               "미디어허브","한신대학교","중부모범","어뮤즈","금빛","처브헬스케어","처브"]:
        if co in f: return co
    for p in ["이미정","김경아","김준영","이강영","차주화","정기학","심창호","경민창","김윤석"]:
        if p in f: return p
    for i in ["국세청","기업은행","우체국","중진공","부평세무소","부평테크노타워","강릉시"]:
        if i in f: return i
    return "에스티엔"

def get_doctype(fname):
    f = fname.replace(".pdf","")
    if any(k in f for k in ["계약서","협약서","양도","양수","MOU"]): return "📝 계약서"
    if any(k in f for k in ["급여","연봉","용역비","품의","채용","이력서","근로"]): return "👤 인사/급여"
    if any(k in f for k in ["국세","지방세","세무소","과태료","건강보험","세금"]): return "🧾 세금/공과"
    if any(k in f for k in ["등기부","등기권리","사업자등록","법인인감","인감증명"]): return "🏢 법인서류"
    if any(k in f for k in ["보고서","월간","자금수지","매출"]): return "📊 내부보고"
    if any(k in f for k in ["공문","서약서","신청서","확약서","동의서"]): return "📋 공문/신청"
    if any(k in f for k in ["영수증","수령","청구","약정금"]): return "💰 영수/청구"
    if any(k in f for k in ["SCAN","Untitled"]): return "🖨️ 스캔문서"
    if any(k in f for k in ["임대차","전대차"]): return "🏠 임대차"
    return "📄 기타"

def generate(scan_folder, output_path):
    # 실제 폴더의 PDF 목록 읽기
    try:
        pdfs = sorted([f for f in os.listdir(scan_folder) if f.lower().endswith('.pdf')])
    except:
        pdfs = list(LAWSUIT_FILES.keys())

    lawsuit_list = [(f, LAWSUIT_FILES[f]) for f in pdfs if f in LAWSUIT_FILES]
    work_list = [(f, get_date(f), get_company(f), get_doctype(f)) for f in pdfs if f not in LAWSUIT_FILES]
    work_list.sort(key=lambda x: x[1])

    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    urgent_n = sum(1 for _,i in lawsuit_list if i[4]=='긴급')
    caution_n = sum(1 for _,i in lawsuit_list if i[4]=='주의')

    # 소송 테이블 행
    lawsuit_rows = ""
    for i,(fname,(company,case_name,case_no,doc_type,urgency)) in enumerate(lawsuit_list,1):
        badge = f'<span class="badge {urgency}">{urgency}</span>'
        lawsuit_rows += f"""<tr>
<td class="center">{i}</td>
<td>{company}</td>
<td>{case_name}</td>
<td class="center">{case_no}</td>
<td class="center">{doc_type}</td>
<td class="center">{badge}</td>
<td><a href="{fname}" class="file-link">📄 {fname}</a></td>
</tr>\n"""

    # 업무 테이블 행
    work_rows = ""
    for i,(fname,date,company,doctype) in enumerate(work_list,1):
        alt = ' class="alt"' if i%2==0 else ''
        work_rows += f"""<tr{alt}>
<td class="center">{i}</td>
<td class="center">{date}</td>
<td class="center">{company}</td>
<td class="center">{doctype}</td>
<td><a href="{fname}" class="file-link">📄 {fname}</a></td>
</tr>\n"""

    html = f"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="60">
<title>스캔관리대장</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:"맑은 고딕",sans-serif;background:#f0f2f5;padding:20px;font-size:13px}}
h1{{color:#1F4E79;font-size:22px;margin-bottom:16px}}
.summary{{display:flex;gap:12px;margin-bottom:20px;flex-wrap:wrap}}
.card{{background:white;border-radius:10px;padding:14px 22px;box-shadow:0 2px 8px rgba(0,0,0,.1);text-align:center;min-width:90px}}
.card .num{{font-size:28px;font-weight:bold;color:#1F4E79}}
.card .label{{font-size:12px;color:#666;margin-top:4px}}
.card.red .num{{color:#e53935}}
.card.orange .num{{color:#FF9900}}

/* 검색 */
.search-box{{display:flex;gap:10px;margin-bottom:16px;align-items:center}}
.search-box input{{padding:8px 14px;border:1px solid #ccc;border-radius:6px;font-size:14px;width:320px;font-family:"맑은 고딕"}}
.search-box select{{padding:8px 10px;border:1px solid #ccc;border-radius:6px;font-size:13px;font-family:"맑은 고딕"}}
.search-box button{{padding:8px 16px;background:#1F4E79;color:white;border:none;border-radius:6px;cursor:pointer;font-family:"맑은 고딕"}}
.search-box button:hover{{background:#16396e}}

/* 탭 */
.tabs{{display:flex;gap:4px;margin-bottom:0}}
.tab{{padding:10px 24px;background:#ddd;border-radius:8px 8px 0 0;cursor:pointer;font-weight:bold;font-size:13px;border:none;font-family:"맑은 고딕"}}
.tab.active{{background:#1F4E79;color:white}}
.tab.green.active{{background:#375623}}
.panel{{display:none}}
.panel.active{{display:block}}

/* 테이블 */
table{{width:100%;border-collapse:collapse;background:white;box-shadow:0 2px 8px rgba(0,0,0,.1)}}
th{{padding:10px 12px;text-align:center;border-bottom:2px solid #dee2e6;white-space:nowrap}}
.lawsuit-tbl th{{background:#1F4E79;color:white}}
.work-tbl th{{background:#375623;color:white}}
td{{padding:9px 12px;border-bottom:1px solid #e9ecef;vertical-align:middle}}
tr:hover td{{background:#f0f7ff!important}}
tr.alt td{{background:#f9fdf9}}
.center{{text-align:center}}
a.file-link{{color:#0563C1;text-decoration:none}}
a.file-link:hover{{text-decoration:underline}}
.badge{{display:inline-block;padding:3px 10px;border-radius:12px;font-size:11px;font-weight:bold}}
.긴급{{background:#e53935;color:white}}
.주의{{background:#FF9900;color:white}}
.일반{{background:#6c757d;color:white}}
.hidden{{display:none}}
.count-info{{color:#666;font-size:12px;margin:8px 0 4px;padding:4px 8px}}
.refresh-btn{{float:right;padding:6px 14px;background:#375623;color:white;border:none;border-radius:6px;cursor:pointer;font-family:"맑은 고딕";font-size:12px}}
.updated{{color:#999;font-size:11px;margin-top:12px;text-align:right}}
</style>
</head>
<body>
<h1>📂 스캔관리대장
<button class="refresh-btn" onclick="location.reload()">🔄 새로고침</button>
</h1>

<div class="summary">
  <div class="card"><div class="num">{len(lawsuit_list)}</div><div class="label">소송문서</div></div>
  <div class="card red"><div class="num">{urgent_n}</div><div class="label">🔴 긴급</div></div>
  <div class="card orange"><div class="num">{caution_n}</div><div class="label">🟡 주의</div></div>
  <div class="card"><div class="num">{len(work_list)}</div><div class="label">업무문서</div></div>
  <div class="card"><div class="num">{len(pdfs)}</div><div class="label">전체</div></div>
</div>

<div class="search-box">
  <input type="text" id="searchInput" placeholder="🔍 파일명, 회사명, 사건명 검색..." oninput="doSearch()">
  <select id="searchScope" onchange="doSearch()">
    <option value="all">전체</option>
    <option value="lawsuit">소송만</option>
    <option value="work">업무만</option>
  </select>
  <button onclick="clearSearch()">초기화</button>
  <span id="countInfo" class="count-info"></span>
</div>

<div class="tabs">
  <button class="tab active" onclick="showTab('lawsuit',this)">⚖️ 소송관리 ({len(lawsuit_list)})</button>
  <button class="tab green" onclick="showTab('work',this)">📋 업무문서 ({len(work_list)})</button>
</div>

<!-- 소송 -->
<div id="panel-lawsuit" class="panel active">
<table class="lawsuit-tbl">
<thead><tr><th>No</th><th>회사(기관)명</th><th>사건명</th><th>사건번호</th><th>문서종류</th><th>긴급도</th><th>파일 열기</th></tr></thead>
<tbody id="lawsuit-body">
{lawsuit_rows}
</tbody>
</table>
</div>

<!-- 업무 -->
<div id="panel-work" class="panel">
<table class="work-tbl">
<thead><tr><th>No</th><th>날짜</th><th>회사(기관)명</th><th>문서종류</th><th>파일 열기</th></tr></thead>
<tbody id="work-body">
{work_rows}
</tbody>
</table>
</div>

<p class="updated">※ 마지막 갱신: {now} &nbsp;|&nbsp; 60초마다 자동 새로고침</p>

<script>
function showTab(name, btn) {{
  document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.getElementById('panel-'+name).classList.add('active');
  btn.classList.add('active');
  doSearch();
}}

function doSearch() {{
  const q = document.getElementById('searchInput').value.toLowerCase().trim();
  const scope = document.getElementById('searchScope').value;
  let total=0, visible=0;

  // 소송 탭 검색
  if(scope!='work') {{
    document.querySelectorAll('#lawsuit-body tr').forEach(tr => {{
      const txt = tr.textContent.toLowerCase();
      const show = !q || txt.includes(q);
      tr.classList.toggle('hidden', !show);
      total++; if(show) visible++;
    }});
  }}

  // 업무 탭 검색
  if(scope!='lawsuit') {{
    document.querySelectorAll('#work-body tr').forEach(tr => {{
      const txt = tr.textContent.toLowerCase();
      const show = !q || txt.includes(q);
      tr.classList.toggle('hidden', !show);
      if(scope=='all') {{ total++; if(show) visible++; }}
      else {{ total++; if(show) visible++; }}
    }});
  }}

  // 탭 자동 전환
  if(scope=='lawsuit') showTabById('lawsuit');
  else if(scope=='work') showTabById('work');

  document.getElementById('countInfo').textContent = q ? `검색결과: ${{visible}}건` : '';
}}

function showTabById(name) {{
  document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));
  document.getElementById('panel-'+name).classList.add('active');
}}

function clearSearch() {{
  document.getElementById('searchInput').value='';
  document.getElementById('searchScope').value='all';
  doSearch();
}}
</script>
</body></html>"""

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)
    print(f"[{datetime.now().strftime('%H:%M:%S')}] HTML 생성 완료 ({len(pdfs)}개 파일)")
    return len(pdfs)

if __name__ == '__main__':
    import time, sys

    # 단순 실행 시 1회 생성
    if len(sys.argv) > 1 and sys.argv[1] == 'once':
        generate(SCAN_FOLDER, OUTPUT_HTML)
        sys.exit(0)

    # 감시 모드
    print("=" * 50)
    print("  스캔관리대장 자동 갱신 감시 시작")
    print("=" * 50)
    print(f"  폴더: {SCAN_FOLDER}")
    print(f"  HTML: {OUTPUT_HTML}")
    print("  종료: Ctrl+C\n")

    prev_count = 0
    while True:
        try:
            files = [f for f in os.listdir(SCAN_FOLDER) if f.lower().endswith('.pdf')]
            if len(files) != prev_count:
                generate(SCAN_FOLDER, OUTPUT_HTML)
                prev_count = len(files)
        except Exception as e:
            print(f"오류: {e}")
        time.sleep(5)
