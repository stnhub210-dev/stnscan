@echo off
chcp 65001 >nul
title 스캔관리대장 자동 갱신
cd /d %~dp0
echo HTML 생성 중...
python generate_html.py once
echo.
echo 브라우저에서 열겠습니다...
start "" "%USERPROFILE%\Desktop\스캔\스캔관리대장.html"
echo.
echo 자동 갱신 감시 시작 (새 파일 추가 시 자동 업데이트)
echo 종료하려면 이 창을 닫으세요.
python generate_html.py
